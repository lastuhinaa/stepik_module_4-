# stepik_auto_tests_course
Работа с Git в курсе: Автоматизация с помощью Selenium и Python.

Лабораторные работы по ТРПО.
